/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.nickdelfieh.kittyhead.init;

import net.nickdelfieh.kittyhead.KittyheadMod;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

public class KittyheadModBlocks {
	public static void load() {
	}

	public static void clientLoad() {
	}

	private static Block register(String registryName, Block block) {
		return Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(KittyheadMod.MODID, registryName), block);
	}
}